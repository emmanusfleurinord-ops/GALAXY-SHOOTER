Galaxy Shooter

Como abrir
Abra o index.html no Chrome, Edge ou Firefox.

Novo
1) Setores
- A cada 10 niveis um setor novo.
- No nivel 1, 11, 21... aparece a tela do setor.
- O HUD mostra o nome do setor.

2) Armas novas (caem no mapa)
- LASER: raio na frente
- MISSEIS: perseguem o inimigo
- LEQUE: 5 tiros abertos
- BOMBA: explode as naves da tela
